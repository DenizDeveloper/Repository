﻿namespace Knabto.Entities
{
    public class CrytoCurrency
    {
        public string Currency { get; set; }
        public string Name { get; set; }
        public decimal Amount { get; set; }
        public decimal Price { get; set; }
    }
}