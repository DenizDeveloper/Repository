﻿namespace CoinMarketCapAdapter.Entities
{
    public class Currency
    {
        public decimal Price { get; set; }
    }
}