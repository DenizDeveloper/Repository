﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoinMarketCapAdapter.Entities
{
    public class CoinMarketCapCryptoResponse
    {
        public List<Data> data { get; set; }
    }
}
