﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Knabto.Contracts
{
    public interface ICalculator
    {
        decimal Multiply(decimal valueOne, decimal valueTwo);
    }
}
